from distutils.core import setup

setup(
    name = "PythonTestModule",
    version="1.1.0",
    py_modules = ["PythonTestModule"],
    author="greenjoa",
    author_email = "greenjoa@gmail.com",
    url="http://www.greenjoa.com",
    description="Test Module",
    )